
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define parseCSV_Debug 0

int parseCSV(char * srcCSV, char* str1, char* str2)
{
	 char c;
	 int i,j;
	 if (parseCSV_Debug)  printf("parseCSV>> The length of the string is %d :\n", strlen(srcCSV));

	 i = 0;
	 j = 0;
	 if (parseCSV_Debug) printf("parseCSV>> Input string: \"%s\"\n",  srcCSV);
	 c = srcCSV[i++];
	 while (c!=',')	 {
		 str1[j++] = c;
		 c = srcCSV[i++];
	 }
	 str1[j++] = '\0';
	 if (parseCSV_Debug) printf("parseCSV>> string1: \"%s\"\n",  str1);
	 c = srcCSV[i++];
	 j = 0;
	 while (c != '\0' && c!=10)	 {
		 str2[j++] = c;
		 c = srcCSV[i++];
	 }
	 str2[j++] = '\0';
	 if (parseCSV_Debug) printf("parseCSV>> string2: \"%s\"\n",  str2);
	 return 0;
}



