#ifndef CONVERSIONS_H_
#define CONVERSIONS_H_

int parseCSV(char * srcCSV, char* str1, char* str2);
#endif
